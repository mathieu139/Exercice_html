# Portfolio Benjamin SEVAULT

Je n'ai aucun problème avec le fait que mon portfolio soit cloné.

J'ai moi-même intégré des éléments produits par d'autres personnes et les ai personnalisé selon mes besoins.

## :rotating_light: **Attention**  :rotating_light:
Le formulaire de contact envoie les messages vers **ma** boîte mail.

Si vous copiez mon portfolio, veillez à **_changer_** l'adresse contenue dans le balise form comme suit :

```html
<form action="https://formsubmit.co/votre_adresse@email.com" method="POST">
  <!-- vos inputs --!>
</form>
```
